package id.tangkapteks

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint

/** Menulis ulang baris yang diedit langsung di atas foto asli. */
object Compositor {
    fun compose(original: Bitmap, lines: List<TextLine>): Bitmap {
        val out = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val fill = Paint().apply { style = Paint.Style.FILL }
        val changed = lines.filter { it.changed }
        // Ambil semua warna latar dari foto asli sebelum ada yang dihapus
        val bgs = changed.map { ImageUtils.sampleBackground(original, it.box) }
        changed.forEachIndexed { i, l ->
            val b = l.box
            val padX = b.height() * 0.25f
            val padY = b.height() * 0.22f
            fill.color = bgs[i]
            canvas.drawRect(b.left - padX, b.top - padY, b.right + padX, b.bottom + padY, fill)
            var fg = l.color
            if (Math.abs(ImageUtils.luminance(fg) - ImageUtils.luminance(bgs[i])) < 70) fg = ImageUtils.contrast(bgs[i])
            TextDrawer.draw(canvas, l, fg, 1f)
        }
        return out
    }
}
