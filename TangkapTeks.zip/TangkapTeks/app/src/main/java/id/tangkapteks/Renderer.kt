package id.tangkapteks

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/** Membuat gambar dan PDF tata letak dari baris-baris teks. Pratinjau dan hasil ekspor memakai kode yang sama. */
object Renderer {

    fun layoutBitmap(lines: List<TextLine>, srcW: Int, srcH: Int, pageBg: Int, k: Float = 1f): Bitmap {
        val w = max(1, (srcW * k).roundToInt())
        val h = max(1, (srcH * k).roundToInt())
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(pageBg)
        for (l in lines) TextDrawer.draw(c, l, l.color, k)
        return bmp
    }

    /** PDF satu halaman selebar A4 (595 pt) dengan tinggi mengikuti foto. Teks tetap berupa teks. */
    fun pdf(lines: List<TextLine>, srcW: Int, srcH: Int, pageBg: Int): ByteArray {
        val pageW = 595
        val pageH = max(1, (pageW.toFloat() * srcH / srcW).roundToInt())
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
        val c = page.canvas
        c.drawColor(pageBg)
        val k = pageW.toFloat() / srcW
        for (l in lines) TextDrawer.draw(c, l, l.color, k)
        doc.finishPage(page)
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
