package id.tangkapteks

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View

/** Menampilkan teks hasil OCR di posisi aslinya. Ketuk baris untuk mengedit. */
class LayoutView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var bitmap: Bitmap? = null
        set(v) { field = v; requestLayout(); invalidate() }
    var lines: List<TextLine> = emptyList()
        set(v) { field = v; invalidate() }
    var pageBg: Int = Color.WHITE
    var showOriginal: Boolean = false
        set(v) { field = v; invalidate() }
    var targetWidth: Int = 0
        set(v) { field = v; requestLayout() }
    var onLineTap: ((TextLine) -> Unit)? = null

    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.rgb(11, 110, 95)
    }
    private val ghost = Paint().apply { alpha = 70 }

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapUp(e: MotionEvent): Boolean {
            val bm = bitmap ?: return false
            val k = width.toFloat() / bm.width
            val slop = 8f
            for (l in lines.asReversed()) {
                val r = RectF(l.box.left * k - slop, l.box.top * k - slop, l.box.right * k + slop, l.box.bottom * k + slop)
                if (r.contains(e.x, e.y)) { onLineTap?.invoke(l); return true }
            }
            return false
        }
    })

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val bm = bitmap
        val w = if (targetWidth > 0) targetWidth else MeasureSpec.getSize(widthSpec)
        val h = if (bm != null) (w.toFloat() * bm.height / bm.width).toInt() else 0
        setMeasuredDimension(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        val bm = bitmap ?: return
        val k = width.toFloat() / bm.width
        canvas.drawColor(pageBg)
        if (showOriginal) {
            canvas.save(); canvas.scale(k, k); canvas.drawBitmap(bm, 0f, 0f, ghost); canvas.restore()
        }
        for (l in lines) {
            TextDrawer.draw(canvas, l, l.color, k)
            if (l.changed) {
                canvas.drawRect(l.box.left * k, l.box.top * k, l.box.right * k, l.box.bottom * k, frame)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = detector.onTouchEvent(event) || super.onTouchEvent(event)

    override fun performClick(): Boolean = super.performClick()
}
