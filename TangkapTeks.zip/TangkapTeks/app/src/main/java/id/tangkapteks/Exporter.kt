package id.tangkapteks

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.text.Html
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.roundToInt

enum class Fmt(val label: String, val ext: String, val mime: String) {
    TXT("TXT", ".txt", "text/plain"),
    DOCX("Word", ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    PDF("PDF", ".pdf", "application/pdf"),
    PNG("PNG", ".png", "image/png")
}

data class ExportOptions(
    var keepSpacing: Boolean = true,   // TXT: pertahankan jarak dan lekuk
    var photoMode: Boolean = false,    // PDF/PNG: foto asli dengan teks hasil edit
    var whiteBg: Boolean = false       // PDF/PNG mode tata letak: latar putih
)

/** Hasil ekspor: isi file, plus bahan pratinjau (teks atau gambar). */
class ExportResult(val bytes: ByteArray, val text: CharSequence?, val image: Bitmap?)

object Exporter {

    fun build(fmt: Fmt, o: ExportOptions, original: Bitmap, lines: List<TextLine>, pageBg: Int): ExportResult =
        when (fmt) {
            Fmt.TXT -> {
                val t = if (o.keepSpacing) TextBuilder.plain(lines) else TextBuilder.flow(lines)
                ExportResult(t.toByteArray(Charsets.UTF_8), t, null)
            }
            Fmt.DOCX -> {
                val preview = Html.fromHtml(TextBuilder.html(lines), Html.FROM_HTML_MODE_COMPACT)
                ExportResult(Docx.build(lines), preview, null)
            }
            Fmt.PNG -> {
                val bmp = page(o, original, lines, pageBg)
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                ExportResult(out.toByteArray(), null, bmp)
            }
            Fmt.PDF -> ExportResult(pdf(o, original, lines, pageBg), null, page(o, original, lines, pageBg))
        }

    private fun readable(fg: Int, bg: Int): Int =
        if (abs(ImageUtils.luminance(fg) - ImageUtils.luminance(bg)) < 70) ImageUtils.contrast(bg) else fg

    /** Halaman penuh sebagai gambar (untuk PNG dan pratinjau PDF). */
    private fun page(o: ExportOptions, original: Bitmap, lines: List<TextLine>, pageBg: Int): Bitmap {
        if (o.photoMode) return Compositor.compose(original, lines)
        val bg = if (o.whiteBg) Color.WHITE else pageBg
        val b = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(bg)
        for (l in lines) TextDrawer.draw(c, l, readable(l.color, bg), 1f)
        return b
    }

    /** PDF satu halaman selebar A4 dengan rasio foto. Teks mode tata letak tetap berupa teks (bisa dipilih). */
    private fun pdf(o: ExportOptions, original: Bitmap, lines: List<TextLine>, pageBg: Int): ByteArray {
        val pw = 595
        val ph = (pw.toFloat() * original.height / original.width).roundToInt().coerceAtLeast(100)
        val doc = PdfDocument()
        val info = PdfDocument.PageInfo.Builder(pw, ph, 1).create()
        val pg = doc.startPage(info)
        val c = pg.canvas
        if (o.photoMode) {
            val b = Compositor.compose(original, lines)
            c.drawBitmap(b, null, Rect(0, 0, pw, ph), Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            val bg = if (o.whiteBg) Color.WHITE else pageBg
            c.drawColor(bg)
            val k = pw.toFloat() / original.width
            for (l in lines) TextDrawer.draw(c, l, readable(l.color, bg), k)
        }
        doc.finishPage(pg)
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
