package id.tangkapteks

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Menyusun teks biasa dan HTML dari baris-baris OCR dengan mempertahankan jarak dan lekuk. */
object TextBuilder {
    private class Row(first: TextLine) {
        val items = mutableListOf(first)
        var cy = first.box.exactCenterY()
        var h = first.box.height()
        val top = first.box.top
        var bottom = first.box.bottom
    }

    private fun rows(lines: List<TextLine>): List<Row> {
        val sorted = lines.sortedWith(compareBy({ it.box.top }, { it.box.left }))
        val rows = mutableListOf<Row>()
        for (l in sorted) {
            val r = rows.lastOrNull()
            if (r != null && abs(l.box.exactCenterY() - r.cy) < min(r.h, l.box.height()) * 0.5f) {
                r.items.add(l)
                r.h = max(r.h, l.box.height())
                r.bottom = max(r.bottom, l.box.bottom)
            } else rows.add(Row(l))
        }
        rows.forEach { r -> r.items.sortBy { it.box.left } }
        return rows
    }

    private fun avgHeight(lines: List<TextLine>): Float = lines.sumOf { it.box.height() }.toFloat() / lines.size

    fun plain(lines: List<TextLine>): String {
        if (lines.isEmpty()) return ""
        val rows = rows(lines)
        val minX = lines.minOf { it.box.left }
        val avgH = avgHeight(lines)
        val out = StringBuilder()
        var prev: Row? = null
        for (r in rows) {
            if (prev != null) {
                out.append('\n')
                if (r.top - prev.bottom > avgH * 0.7f) out.append('\n')
            }
            var cursor = 0
            r.items.forEachIndexed { i, l ->
                val cw = max(l.box.height() * 0.5f, 6f)
                val gap = if (i == 0) ((l.box.left - minX) / cw).roundToInt().coerceIn(0, 40)
                else ((l.box.left - cursor) / cw).roundToInt().coerceIn(2, 20)
                repeat(gap) { out.append(' ') }
                out.append(l.text)
                cursor = l.box.right
            }
            prev = r
        }
        return out.toString()
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    fun html(lines: List<TextLine>): String {
        if (lines.isEmpty()) return ""
        val rows = rows(lines)
        val avgH = avgHeight(lines)
        val minX = lines.minOf { it.box.left }
        val maxR = lines.maxOf { it.box.right }
        val sb = StringBuilder()
        var prev: Row? = null
        for (r in rows) {
            val mt = if (prev != null && r.top - prev.bottom > avgH * 0.7f) 12 else 0
            val first = r.items.first()
            val last = r.items.last()
            val mid = (first.box.left + last.box.right) / 2f
            val align = when {
                r.items.size == 1 && abs(mid - (minX + maxR) / 2f) < (maxR - minX) * 0.06f &&
                    first.box.left - minX > (maxR - minX) * 0.1f -> "center"
                r.items.size == 1 && maxR - last.box.right < (maxR - minX) * 0.03f &&
                    first.box.left - minX > (maxR - minX) * 0.3f -> "right"
                else -> "left"
            }
            val inner = r.items.joinToString("&nbsp;&nbsp;&nbsp;&nbsp;") { l ->
                var s = esc(l.text)
                if (l.bold) s = "<b>$s</b>"
                if (l.italic) s = "<i>$s</i>"
                s
            }
            val pt = (r.h / avgH * 11f).coerceIn(9f, 28f)
            sb.append("<p style=\"margin:${mt}px 0 0;text-align:$align;font-size:${pt.roundToInt()}pt\">$inner</p>")
            prev = r
        }
        return sb.toString()
    }
}
