package id.tangkapteks

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Menyusun teks biasa dan HTML dari baris-baris OCR dengan mempertahankan jarak dan lekuk. */
object TextBuilder {
    private class Row(first: TextLine) {
        val items = mutableListOf(first)
        var cy = first.box.exactCenterY()
        var h = first.box.height()
        val top = first.box.top
        var bottom = first.box.bottom
    }

    private fun rows(lines: List<TextLine>): List<Row> {
        val sorted = lines.sortedWith(compareBy({ it.box.top }, { it.box.left }))
        val rows = mutableListOf<Row>()
        for (l in sorted) {
            val r = rows.lastOrNull()
            if (r != null && abs(l.box.exactCenterY() - r.cy) < min(r.h, l.box.height()) * 0.5f) {
                r.items.add(l)
                r.h = max(r.h, l.box.height())
                r.bottom = max(r.bottom, l.box.bottom)
            } else rows.add(Row(l))
        }
        rows.forEach { r -> r.items.sortBy { it.box.left } }
        return rows
    }

    private fun avgHeight(lines: List<TextLine>): Float = lines.sumOf { it.box.height() }.toFloat() / lines.size

    fun ordered(lines: List<TextLine>): List<TextLine> =
        lines.sortedWith(compareBy({ it.box.top }, { it.box.left }))

    /** keepLayout = false: satu baris per baris foto, tanpa lekuk dan baris kosong. */
    fun plain(lines: List<TextLine>, keepLayout: Boolean = true): String {
        if (lines.isEmpty()) return ""
        if (!keepLayout) return rows(lines).joinToString("\n") { r -> r.items.joinToString(" ") { it.text } }
        val rows = rows(lines)
        val minX = lines.minOf { it.box.left }
        val avgH = avgHeight(lines)
        val out = StringBuilder()
        var prev: Row? = null
        for (r in rows) {
            if (prev != null) {
                out.append('\n')
                if (r.top - prev.bottom > avgH * 0.7f) out.append('\n')
            }
            var cursor = 0
            r.items.forEachIndexed { i, l ->
                val cw = max(l.box.height() * 0.5f, 6f)
                val gap = if (i == 0) ((l.box.left - minX) / cw).roundToInt().coerceIn(0, 40)
                else ((l.box.left - cursor) / cw).roundToInt().coerceIn(2, 20)
                repeat(gap) { out.append(' ') }
                out.append(l.text)
                cursor = l.box.right
            }
            prev = r
        }
        return out.toString()
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    fun html(lines: List<TextLine>): String {
        if (lines.isEmpty()) return ""
        val rows = rows(lines)
        val avgH = avgHeight(lines)
        val minX = lines.minOf { it.box.left }
        val maxR = lines.maxOf { it.box.right }
        val sb = StringBuilder()
        var prev: Row? = null
        for (r in rows) {
            val mt = if (prev != null && r.top - prev.bottom > avgH * 0.7f) 12 else 0
            val first = r.items.first()
            val last = r.items.last()
            val mid = (first.box.left + last.box.right) / 2f
            val align = when {
                r.items.size == 1 && abs(mid - (minX + maxR) / 2f) < (maxR - minX) * 0.06f &&
                    first.box.left - minX > (maxR - minX) * 0.1f -> "center"
                r.items.size == 1 && maxR - last.box.right < (maxR - minX) * 0.03f &&
                    first.box.left - minX > (maxR - minX) * 0.3f -> "right"
                else -> "left"
            }
            val inner = r.items.joinToString("&nbsp;&nbsp;&nbsp;&nbsp;") { l ->
                var s = esc(l.text)
                if (l.bold) s = "<b>$s</b>"
                if (l.italic) s = "<i>$s</i>"
                s
            }
            val pt = (r.h / avgH * 11f).coerceIn(9f, 28f)
            sb.append("<p style=\"margin:${mt}px 0 0;text-align:$align;font-size:${pt.roundToInt()}pt\">$inner</p>")
            prev = r
        }
        return sb.toString()
    }

    /** Teks mengalir: tanpa lekuk dan jarak kolom, paragraf dipisah baris kosong. */
    fun flow(lines: List<TextLine>): String {
        if (lines.isEmpty()) return ""
        val rows = rows(lines)
        val avgH = avgHeight(lines)
        val out = StringBuilder()
        var prev: Row? = null
        for (r in rows) {
            if (prev != null) {
                out.append('\n')
                if (r.top - prev.bottom > avgH * 0.7f) out.append('\n')
            }
            out.append(r.items.joinToString(" ") { it.text })
            prev = r
        }
        return out.toString()
    }

    private fun alignOf(r: Row, minX: Int, maxR: Int): String {
        val first = r.items.first()
        val last = r.items.last()
        val mid = (first.box.left + last.box.right) / 2f
        val span = (maxR - minX).coerceAtLeast(1)
        return when {
            r.items.size == 1 && abs(mid - (minX + maxR) / 2f) < span * 0.06f &&
                first.box.left - minX > span * 0.1f -> "center"
            r.items.size == 1 && maxR - last.box.right < span * 0.03f &&
                first.box.left - minX > span * 0.3f -> "right"
            else -> "left"
        }
    }

    private fun escXml(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** Isi <w:body> untuk berkas Word: satu paragraf per baris, dengan rata, lekuk, tebal, miring. */
    fun docxBody(lines: List<TextLine>): String {
        if (lines.isEmpty()) return "<w:p/>"
        val rows = rows(lines)
        val avgH = avgHeight(lines)
        val minX = lines.minOf { it.box.left }
        val maxR = lines.maxOf { it.box.right }
        val span = (maxR - minX).coerceAtLeast(1)
        val sb = StringBuilder()
        var prev: Row? = null
        for (r in rows) {
            val before = if (prev != null && r.top - prev.bottom > avgH * 0.7f) 240 else 0
            val align = alignOf(r, minX, maxR)
            val first = r.items.first()
            val ind = if (align == "left") ((first.box.left - minX).toFloat() / span * 9000f).toInt() else 0
            val half = ((r.h / avgH * 11f).coerceIn(9f, 28f) * 2f).roundToInt()
            sb.append("<w:p><w:pPr><w:spacing w:before=\"$before\" w:after=\"0\"/><w:ind w:left=\"$ind\"/><w:jc w:val=\"$align\"/></w:pPr>")
            r.items.forEachIndexed { i, l ->
                if (i > 0) sb.append("<w:r><w:tab/></w:r>")
                sb.append("<w:r><w:rPr>")
                if (l.bold) sb.append("<w:b/>")
                if (l.italic) sb.append("<w:i/>")
                sb.append("<w:sz w:val=\"$half\"/></w:rPr><w:t xml:space=\"preserve\">${escXml(l.text)}</w:t></w:r>")
            }
            sb.append("</w:p>")
            prev = r
        }
        return sb.toString()
    }
}
