package id.tangkapteks

import android.graphics.Bitmap
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService

/** Dialog pilihan ekspor dengan pratinjau sebelum file disimpan atau dibagikan. */
class ExportDialog(
    private val act: AppCompatActivity,
    private val original: Bitmap,
    private val lines: List<TextLine>,
    private val pageBg: Int,
    private val io: ExecutorService,
    private val onSave: (bytes: ByteArray, name: String, mime: String) -> Unit,
    private val onShare: (bytes: ByteArray, name: String, mime: String) -> Unit
) {
    private var fmt = Fmt.TXT
    private val opts = ExportOptions()
    private var result: ExportResult? = null
    private var token = 0

    private lateinit var optText: View
    private lateinit var optImage: View
    private lateinit var optWhite: CheckBox
    private lateinit var previewText: TextView
    private lateinit var previewTextScroll: View
    private lateinit var previewImage: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var info: TextView
    private lateinit var btnSave: Button
    private lateinit var btnShare: Button

    fun show() {
        val v = act.layoutInflater.inflate(R.layout.dialog_export, null)
        val group = v.findViewById<MaterialButtonToggleGroup>(R.id.fmtGroup)
        optText = v.findViewById(R.id.optText)
        optImage = v.findViewById(R.id.optImage)
        optWhite = v.findViewById(R.id.optWhite)
        previewText = v.findViewById(R.id.previewText)
        previewTextScroll = v.findViewById(R.id.previewTextScroll)
        previewImage = v.findViewById(R.id.previewImage)
        progress = v.findViewById(R.id.previewProgress)
        info = v.findViewById(R.id.previewInfo)
        btnSave = v.findViewById(R.id.btnExportSave)
        btnShare = v.findViewById(R.id.btnExportShare)

        val dlg = AlertDialog.Builder(act).setView(v).create()

        group.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            fmt = when (id) {
                R.id.fmtDocx -> Fmt.DOCX
                R.id.fmtPdf -> Fmt.PDF
                R.id.fmtPng -> Fmt.PNG
                else -> Fmt.TXT
            }
            optText.visibility = if (fmt == Fmt.TXT) View.VISIBLE else View.GONE
            optImage.visibility = if (fmt == Fmt.PDF || fmt == Fmt.PNG) View.VISIBLE else View.GONE
            refresh()
        }
        v.findViewById<CheckBox>(R.id.optSpacing).setOnCheckedChangeListener { _, c ->
            opts.keepSpacing = c; refresh()
        }
        v.findViewById<RadioGroup>(R.id.rgMode).setOnCheckedChangeListener { _, id ->
            opts.photoMode = id == R.id.rbPhoto
            optWhite.isEnabled = !opts.photoMode
            refresh()
        }
        optWhite.setOnCheckedChangeListener { _, c -> opts.whiteBg = c; refresh() }

        btnSave.setOnClickListener {
            val r = result ?: return@setOnClickListener
            onSave(r.bytes, fileName(), fmt.mime)
            dlg.dismiss()
        }
        btnShare.setOnClickListener {
            val r = result ?: return@setOnClickListener
            onShare(r.bytes, fileName(), fmt.mime)
            dlg.dismiss()
        }
        v.findViewById<Button>(R.id.btnExportClose).setOnClickListener { dlg.dismiss() }

        dlg.show()
        group.check(R.id.fmtTxt)
    }

    private fun fileName(): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "TangkapTeks_$stamp${fmt.ext}"
    }

    private fun refresh() {
        val my = ++token
        val f = fmt
        val o = opts.copy()
        progress.visibility = View.VISIBLE
        btnSave.isEnabled = false
        btnShare.isEnabled = false
        info.text = ""
        io.execute {
            val r = try { Exporter.build(f, o, original, lines, pageBg) } catch (e: Exception) { null }
            act.runOnUiThread {
                if (my == token) {
                    progress.visibility = View.GONE
                    result = r
                    if (r == null) {
                        info.text = "Pratinjau gagal disusun."
                    } else {
                        showPreview(f, r)
                        btnSave.isEnabled = true
                        btnShare.isEnabled = true
                    }
                }
            }
        }
    }

    private fun showPreview(f: Fmt, r: ExportResult) {
        if (r.image != null) {
            previewTextScroll.visibility = View.GONE
            previewImage.visibility = View.VISIBLE
            previewImage.setImageBitmap(r.image)
        } else {
            previewImage.visibility = View.GONE
            previewTextScroll.visibility = View.VISIBLE
            previewText.typeface = if (f == Fmt.TXT) Typeface.MONOSPACE else Typeface.SANS_SERIF
            previewText.text = r.text
        }
        val kb = r.bytes.size / 1024.0
        val size = if (kb >= 1024) String.format(Locale.US, "%.1f MB", kb / 1024) else String.format(Locale.US, "%.0f KB", kb)
        info.text = "${f.label} · $size · ${lines.count { it.changed }} baris diedit"
    }
}
