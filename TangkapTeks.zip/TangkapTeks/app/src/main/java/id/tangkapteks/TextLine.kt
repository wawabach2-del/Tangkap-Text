package id.tangkapteks

import android.graphics.Color
import android.graphics.Rect

/** Satu baris teks hasil OCR beserta posisinya (piksel pada foto kerja). */
data class TextLine(
    var text: String,
    val orig: String,
    val box: Rect,
    var bold: Boolean = false,
    var italic: Boolean = false,
    var color: Int = Color.BLACK,
    var bg: Int = Color.WHITE
) {
    val changed: Boolean get() = text != orig
}
