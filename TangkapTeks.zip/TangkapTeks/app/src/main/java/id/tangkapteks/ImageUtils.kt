package id.tangkapteks

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object ImageUtils {
    private const val MAX_SIDE = 2400

    /** Membuka foto, memperbaiki orientasi EXIF, dan memperkecil bila terlalu besar. */
    fun load(ctx: Context, uri: Uri): Bitmap? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        }
        val k = min(1f, MAX_SIDE.toFloat() / max(raw.width, raw.height))
        m.postScale(k, k)
        return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    }

    fun rotate90(src: Bitmap): Bitmap {
        val m = Matrix().apply { postRotate(90f) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun median(l: MutableList<Int>): Int {
        l.sort()
        return l[l.size / 2]
    }

    /** Warna latar: median piksel pada cincin tipis di sekeliling kotak. */
    fun sampleBackground(bmp: Bitmap, r: Rect): Int {
        val pad = max(3, r.height() / 8)
        val rs = ArrayList<Int>(); val gs = ArrayList<Int>(); val bs = ArrayList<Int>()
        fun add(x: Int, y: Int) {
            val p = bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1))
            rs.add(Color.red(p)); gs.add(Color.green(p)); bs.add(Color.blue(p))
        }
        val step = max(1, max(r.width(), r.height()) / 60)
        var x = r.left
        while (x <= r.right) { add(x, r.top - pad); add(x, r.bottom + pad); x += step }
        var y = r.top
        while (y <= r.bottom) { add(r.left - pad, y); add(r.right + pad, y); y += step }
        return Color.rgb(median(rs), median(gs), median(bs))
    }

    /** Warna tulisan: rata-rata piksel yang paling jauh dari warna latar di dalam kotak. */
    fun sampleTextColor(bmp: Bitmap, r: Rect, bg: Int): Int {
        val left = r.left.coerceIn(0, bmp.width - 1)
        val right = r.right.coerceIn(left + 1, bmp.width)
        val top = r.top.coerceIn(0, bmp.height - 1)
        val bottom = r.bottom.coerceIn(top + 1, bmp.height)
        val step = max(1, ((right - left) * (bottom - top) / 4000.0).let { Math.sqrt(it).toInt() })
        val px = ArrayList<Pair<Int, Int>>() // jarak, warna
        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val p = bmp.getPixel(x, y)
                val d = abs(Color.red(p) - Color.red(bg)) + abs(Color.green(p) - Color.green(bg)) + abs(Color.blue(p) - Color.blue(bg))
                px.add(d to p)
                x += step
            }
            y += step
        }
        if (px.isEmpty()) return contrast(bg)
        px.sortByDescending { it.first }
        if (px[0].first < 90) return contrast(bg)
        val take = max(1, px.size / 8)
        var rr = 0; var gg = 0; var bb = 0
        for (i in 0 until take) {
            val c = px[i].second
            rr += Color.red(c); gg += Color.green(c); bb += Color.blue(c)
        }
        return Color.rgb(rr / take, gg / take, bb / take)
    }

    fun luminance(c: Int): Double = 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)

    fun contrast(bg: Int): Int = if (luminance(bg) > 128) Color.rgb(17, 17, 17) else Color.rgb(245, 245, 245)
}
