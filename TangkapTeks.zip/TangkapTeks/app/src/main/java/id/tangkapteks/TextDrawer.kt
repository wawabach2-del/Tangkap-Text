package id.tangkapteks

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.max

/** Menggambar satu baris tepat di dalam kotaknya: tinggi huruf dan lebar disesuaikan. */
object TextDrawer {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** k = skala dari piksel foto ke piksel kanvas. */
    fun draw(c: Canvas, l: TextLine, color: Int, k: Float) {
        val h = l.box.height() * k
        val style = when {
            l.bold && l.italic -> Typeface.BOLD_ITALIC
            l.bold -> Typeface.BOLD
            l.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        paint.typeface = Typeface.create(Typeface.SANS_SERIF, style)
        paint.textSize = max(6f, h * 0.85f)
        paint.color = color
        val tw = max(1f, paint.measureText(l.text))
        var sx = (l.box.width() * k / tw).coerceIn(0.5f, 1.6f)
        if (l.text.length < 3) sx = 1f
        c.save()
        c.translate(l.box.left * k, l.box.top * k + h * 0.8f)
        c.scale(sx, 1f)
        c.drawText(l.text, 0f, 0f, paint)
        c.restore()
    }
}
