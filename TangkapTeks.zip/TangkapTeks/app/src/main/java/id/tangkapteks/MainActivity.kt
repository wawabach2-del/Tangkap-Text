package id.tangkapteks

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Html
import android.text.InputType
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

internal enum class Fmt { TXT, HTML, PDF, IMAGE, PHOTO }

internal class ExportFile(val bytes: ByteArray, val mime: String, val ext: String)

class MainActivity : AppCompatActivity() {

    private val io = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private var bitmap: Bitmap? = null
    private var lines: List<TextLine> = emptyList()
    private var pageBg: Int = Color.WHITE
    private var result: Bitmap? = null
    private var cameraUri: Uri? = null
    private var previewToken = 0

    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var toggle: MaterialButtonToggleGroup
    private lateinit var preview: ImageView
    private lateinit var panelLayout: View
    private lateinit var panelText: View
    private lateinit var panelPhoto: View
    private lateinit var panelExport: View
    private lateinit var layoutView: LayoutView
    private lateinit var plainText: TextView
    private lateinit var resultImage: ImageView
    private lateinit var btnScan: Button
    private lateinit var vScroll: ScrollView

    private lateinit var exportFormat: RadioGroup
    private lateinit var optKeep: CheckBox
    private lateinit var optOriginal: CheckBox
    private lateinit var btnPick: Button
    private lateinit var previewInfo: TextView
    private lateinit var previewText: TextView
    private lateinit var previewImage: ImageView
    private lateinit var btnExport: Button
    private lateinit var btnExportShare: Button

    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadUri(uri)
    }
    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) cameraUri?.let { loadUri(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        toggle = findViewById(R.id.toggle)
        preview = findViewById(R.id.preview)
        panelLayout = findViewById(R.id.panelLayout)
        panelText = findViewById(R.id.panelText)
        panelPhoto = findViewById(R.id.panelPhoto)
        panelExport = findViewById(R.id.panelExport)
        layoutView = findViewById(R.id.layoutView)
        plainText = findViewById(R.id.plainText)
        resultImage = findViewById(R.id.resultImage)
        btnScan = findViewById(R.id.btnScan)
        vScroll = findViewById(R.id.vScroll)

        exportFormat = findViewById(R.id.exportFormat)
        optKeep = findViewById(R.id.optKeep)
        optOriginal = findViewById(R.id.optOriginal)
        btnPick = findViewById(R.id.btnPick)
        previewInfo = findViewById(R.id.previewInfo)
        previewText = findViewById(R.id.previewText)
        previewImage = findViewById(R.id.previewImage)
        btnExport = findViewById(R.id.btnExport)
        btnExportShare = findViewById(R.id.btnExportShare)

        findViewById<Button>(R.id.btnGallery).setOnClickListener {
            pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<Button>(R.id.btnCamera).setOnClickListener { openCamera() }
        findViewById<Button>(R.id.btnRotate).setOnClickListener {
            val b = bitmap ?: return@setOnClickListener
            io.execute {
                val r = ImageUtils.rotate90(b)
                runOnUiThread { setBitmap(r) }
            }
        }
        btnScan.setOnClickListener { scan() }

        toggle.addOnButtonCheckedListener { _, id, checked -> if (checked) showTab(id) }

        layoutView.onLineTap = { editLine(it) }
        findViewById<CheckBox>(R.id.chkOriginal).setOnCheckedChangeListener { _, on -> layoutView.showOriginal = on }
        findViewById<SeekBar>(R.id.zoom).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val base = vScroll.width
                if (base > 0) layoutView.targetWidth = base * (100 + p) / 100
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnCopy).setOnClickListener { copy(false) }
        findViewById<Button>(R.id.btnCopyRich).setOnClickListener { copy(true) }
        findViewById<Button>(R.id.btnShare).setOnClickListener {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, TextBuilder.plain(lines))
            }
            startActivity(Intent.createChooser(send, getString(R.string.share)))
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveResult() }

        // Ekspor
        exportFormat.setOnCheckedChangeListener { _, _ -> refreshPreview() }
        optKeep.setOnCheckedChangeListener { _, _ -> refreshPreview() }
        optOriginal.setOnCheckedChangeListener { _, _ -> refreshPreview() }
        btnPick.setOnClickListener { pickLines() }
        btnExport.setOnClickListener { doExport(false) }
        btnExportShare.setOnClickListener { doExport(true) }

        // Animasi pembuka hanya saat aplikasi baru dibuka
        if (savedInstanceState == null) playIntro() else findViewById<View>(R.id.intro).visibility = View.GONE
    }

    // ---------- animasi pembuka ----------

    private fun playIntro() {
        val intro = findViewById<View>(R.id.intro)
        val logo = findViewById<View>(R.id.introLogo)
        val title = findViewById<View>(R.id.introTitle)
        val bar = findViewById<View>(R.id.introBar)
        val dp = resources.displayMetrics.density
        var finished = false

        fun endIntro() {
            if (finished) return
            finished = true
            logo.animate().cancel(); title.animate().cancel(); bar.animate().cancel()
            intro.animate().alpha(0f).setDuration(300).withEndAction { intro.visibility = View.GONE }.start()
        }

        logo.alpha = 0f; logo.scaleX = 0.6f; logo.scaleY = 0.6f
        title.alpha = 0f; title.translationY = 24 * dp
        bar.pivotX = 0f; bar.scaleX = 0f

        logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(700).setInterpolator(OvershootInterpolator(1.5f)).start()
        title.animate().alpha(1f).translationY(0f)
            .setStartDelay(450).setDuration(450).setInterpolator(AccelerateDecelerateInterpolator()).start()
        bar.animate().scaleX(1f)
            .setStartDelay(500).setDuration(1100).setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction { endIntro() }.start()

        intro.setOnClickListener { endIntro() }
    }

    // ---------- foto ----------

    private fun openCamera() {
        val dir = File(cacheDir, "images").apply { mkdirs() }
        val file = File(dir, "capture.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        cameraUri = uri
        takePicture.launch(uri)
    }

    private fun loadUri(uri: Uri) {
        setStatus("Membuka foto...")
        io.execute {
            val bm = try { ImageUtils.load(this, uri) } catch (e: Exception) { null }
            runOnUiThread {
                if (bm == null) setStatus("Foto tidak bisa dibuka.") else setBitmap(bm)
            }
        }
    }

    private fun setBitmap(bm: Bitmap) {
        bitmap = bm
        lines = emptyList()
        result = null
        toggle.visibility = View.GONE
        panelLayout.visibility = View.GONE
        panelText.visibility = View.GONE
        panelPhoto.visibility = View.GONE
        panelExport.visibility = View.GONE
        preview.visibility = View.VISIBLE
        preview.setImageBitmap(bm)
        btnScan.isEnabled = true
        setStatus("Foto siap. Tekan Tangkap teks.")
    }

    private fun setStatus(t: String) { status.text = t }

    // ---------- OCR ----------

    private fun scan() {
        val bm = bitmap ?: return
        btnScan.isEnabled = false
        progress.visibility = View.VISIBLE
        setStatus("Membaca teks...")
        recognizer.process(InputImage.fromBitmap(bm, 0))
            .addOnSuccessListener { text ->
                io.execute {
                    val out = mutableListOf<TextLine>()
                    for (block in text.textBlocks) for (ln in block.lines) {
                        val r = ln.boundingBox ?: continue
                        if (ln.text.isBlank()) continue
                        val box = Rect(r)
                        val bg = ImageUtils.sampleBackground(bm, box)
                        val fg = ImageUtils.sampleTextColor(bm, box, bg)
                        out.add(TextLine(ln.text, ln.text, box, color = fg, bg = bg))
                    }
                    val page = ImageUtils.sampleBackground(bm, Rect(0, 0, bm.width - 1, bm.height - 1))
                    runOnUiThread { showResults(out, page) }
                }
            }
            .addOnFailureListener {
                progress.visibility = View.GONE
                btnScan.isEnabled = true
                setStatus("Gagal membaca teks. Coba foto lain.")
            }
    }

    private fun showResults(found: List<TextLine>, page: Int) {
        progress.visibility = View.GONE
        btnScan.isEnabled = true
        if (found.isEmpty()) {
            setStatus("Tidak ada teks yang terbaca di foto ini.")
            return
        }
        lines = found
        pageBg = page
        setStatus("Selesai: ${found.size} baris teks.")
        layoutView.pageBg = page
        layoutView.bitmap = bitmap
        layoutView.lines = lines
        vScroll.post { layoutView.targetWidth = vScroll.width }
        toggle.visibility = View.VISIBLE
        if (toggle.checkedButtonId == R.id.tabLayout) showTab(R.id.tabLayout) else toggle.check(R.id.tabLayout)
    }

    private fun showTab(id: Int) {
        preview.visibility = View.GONE
        panelLayout.visibility = if (id == R.id.tabLayout) View.VISIBLE else View.GONE
        panelText.visibility = if (id == R.id.tabText) View.VISIBLE else View.GONE
        panelPhoto.visibility = if (id == R.id.tabPhoto) View.VISIBLE else View.GONE
        panelExport.visibility = if (id == R.id.tabExport) View.VISIBLE else View.GONE
        when (id) {
            R.id.tabLayout -> layoutView.invalidate()
            R.id.tabText -> plainText.text = TextBuilder.plain(lines)
            R.id.tabPhoto -> buildPhoto()
            R.id.tabExport -> refreshPreview()
        }
    }

    // ---------- edit ----------

    private fun editLine(l: TextLine) {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
        }
        val et = EditText(this).apply {
            setText(l.text)
            setSelection(text.length)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val cbBold = CheckBox(this).apply { text = getString(R.string.bold); isChecked = l.bold }
        val cbItalic = CheckBox(this).apply { text = getString(R.string.italic); isChecked = l.italic }
        col.addView(et)
        col.addView(cbBold)
        col.addView(cbItalic)
        AlertDialog.Builder(this)
            .setTitle(R.string.edit_line)
            .setView(col)
            .setPositiveButton(R.string.ok) { _, _ ->
                l.text = et.text.toString()
                l.bold = cbBold.isChecked
                l.italic = cbItalic.isChecked
                layoutView.invalidate()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------- salin ----------

    private fun copy(rich: Boolean) {
        val plain = TextBuilder.plain(lines)
        val clip = if (rich) ClipData.newHtmlText("Tangkap Teks", plain, TextBuilder.html(lines))
        else ClipData.newPlainText("Tangkap Teks", plain)
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
        Toast.makeText(this, if (rich) "Tersalin dengan format" else "Tersalin", Toast.LENGTH_SHORT).show()
    }

    // ---------- ganti teks di foto ----------

    private fun buildPhoto() {
        val bm = bitmap ?: return
        val snapshot = lines.map { it.copy(box = Rect(it.box)) }
        io.execute {
            val out = Compositor.compose(bm, snapshot)
            runOnUiThread {
                result = out
                resultImage.setImageBitmap(out)
                val n = snapshot.count { it.changed }
                if (n == 0) Toast.makeText(this, "Belum ada baris yang diubah. Edit dulu di tab Tata letak.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun saveResult() {
        val out = result ?: bitmap ?: return
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "TangkapTeks_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/TangkapTeks")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(this, "Gagal menyimpan gambar", Toast.LENGTH_SHORT).show()
            return
        }
        contentResolver.openOutputStream(uri)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        Toast.makeText(this, "Tersimpan di Galeri (Pictures/TangkapTeks)", Toast.LENGTH_LONG).show()
    }

    // ---------- ekspor ----------

    private fun currentFormat(): Fmt = when (exportFormat.checkedRadioButtonId) {
        R.id.fmtHtml -> Fmt.HTML
        R.id.fmtPdf -> Fmt.PDF
        R.id.fmtImage -> Fmt.IMAGE
        R.id.fmtPhoto -> Fmt.PHOTO
        else -> Fmt.TXT
    }

    /** Baris yang akan diekspor: hanya yang dipilih, memakai teks asli bila diminta. */
    private fun exportLines(): List<TextLine> {
        val useOriginal = optOriginal.isChecked
        return lines.filter { it.include }.map {
            if (useOriginal) it.copy(text = it.orig, box = Rect(it.box)) else it.copy(box = Rect(it.box))
        }
    }

    private fun pickLines() {
        if (lines.isEmpty()) return
        val ord = TextBuilder.ordered(lines)
        val labels = ord.map { if (it.text.length > 70) it.text.take(70) + "…" else it.text }.toTypedArray()
        val checked = BooleanArray(ord.size) { ord[it].include }
        AlertDialog.Builder(this)
            .setTitle(R.string.pick_lines)
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(R.string.ok) { _, _ ->
                ord.forEachIndexed { i, l -> l.include = checked[i] }
                refreshPreview()
            }
            .setNeutralButton(R.string.select_all) { _, _ ->
                ord.forEach { it.include = true }
                refreshPreview()
            }
            .setNegativeButton(R.string.select_none) { _, _ ->
                ord.forEach { it.include = false }
                refreshPreview()
            }
            .show()
    }

    private fun showTextPreview(t: CharSequence) {
        previewImage.visibility = View.GONE
        previewText.visibility = View.VISIBLE
        previewText.text = t
    }

    /** Pratinjau memakai kode yang sama dengan hasil ekspor, jadi yang terlihat di sini yang tersimpan. */
    private fun refreshPreview() {
        val bm = bitmap ?: return
        if (lines.isEmpty()) return
        val fmt = currentFormat()
        val ex = exportLines()
        val total = lines.size
        btnPick.text = "${getString(R.string.pick_lines)} (${ex.size} dari $total)"
        optKeep.isEnabled = fmt == Fmt.TXT
        val noLines = ex.isEmpty() && fmt != Fmt.PHOTO
        btnExport.isEnabled = !noLines
        btnExportShare.isEnabled = !noLines
        val token = ++previewToken

        if (noLines) {
            previewInfo.text = "Tidak ada baris dipilih."
            showTextPreview("(kosong)")
            return
        }
        when (fmt) {
            Fmt.TXT -> {
                previewInfo.text = "${ex.size} baris, teks biasa."
                showTextPreview(TextBuilder.plain(ex, optKeep.isChecked))
            }
            Fmt.HTML -> {
                previewInfo.text = "${ex.size} baris, tebal dan miring ikut."
                showTextPreview(Html.fromHtml(TextBuilder.html(ex), Html.FROM_HTML_MODE_COMPACT))
            }
            else -> {
                previewInfo.text = when (fmt) {
                    Fmt.PDF -> "${ex.size} baris, halaman PDF mengikuti ukuran foto."
                    Fmt.IMAGE -> "${ex.size} baris, gambar tata letak."
                    else -> "${lines.count { it.changed }} baris diganti di foto asli."
                }
                previewText.visibility = View.GONE
                previewImage.visibility = View.VISIBLE
                val snap = lines.map { it.copy(box = Rect(it.box)) }
                io.execute {
                    val img = if (fmt == Fmt.PHOTO) Compositor.compose(bm, snap)
                    else Renderer.layoutBitmap(ex, bm.width, bm.height, pageBg, min(1f, 1200f / max(bm.width, bm.height)))
                    runOnUiThread { if (token == previewToken) previewImage.setImageBitmap(img) }
                }
            }
        }
    }

    private fun compress(b: Bitmap, f: Bitmap.CompressFormat, q: Int): ByteArray {
        val o = ByteArrayOutputStream()
        b.compress(f, q, o)
        return o.toByteArray()
    }

    private fun buildFile(fmt: Fmt, ex: List<TextLine>, snap: List<TextLine>, bm: Bitmap, keep: Boolean): ExportFile =
        when (fmt) {
            Fmt.TXT -> ExportFile(TextBuilder.plain(ex, keep).toByteArray(Charsets.UTF_8), "text/plain", "txt")
            Fmt.HTML -> {
                val html = "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>Tangkap Teks</title></head>" +
                    "<body style=\"font-family:sans-serif\">" + TextBuilder.html(ex) + "</body></html>"
                ExportFile(html.toByteArray(Charsets.UTF_8), "text/html", "html")
            }
            Fmt.PDF -> ExportFile(Renderer.pdf(ex, bm.width, bm.height, pageBg), "application/pdf", "pdf")
            Fmt.IMAGE -> ExportFile(
                compress(Renderer.layoutBitmap(ex, bm.width, bm.height, pageBg), Bitmap.CompressFormat.PNG, 100),
                "image/png", "png"
            )
            Fmt.PHOTO -> ExportFile(
                compress(Compositor.compose(bm, snap), Bitmap.CompressFormat.JPEG, 95),
                "image/jpeg", "jpg"
            )
        }

    private fun saveToDownloads(f: ExportFile): Uri? {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "TangkapTeks_$stamp.${f.ext}")
            put(MediaStore.Downloads.MIME_TYPE, f.mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/TangkapTeks")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
        val stream = contentResolver.openOutputStream(uri) ?: return null
        stream.use { it.write(f.bytes) }
        return uri
    }

    private fun doExport(share: Boolean) {
        val bm = bitmap ?: return
        val fmt = currentFormat()
        val ex = exportLines()
        val snap = lines.map { it.copy(box = Rect(it.box)) }
        val keep = optKeep.isChecked
        btnExport.isEnabled = false
        btnExportShare.isEnabled = false
        io.execute {
            val file = try { buildFile(fmt, ex, snap, bm, keep) } catch (e: Exception) { null }
            val uri = if (file != null) try { saveToDownloads(file) } catch (e: Exception) { null } else null
            runOnUiThread {
                btnExport.isEnabled = true
                btnExportShare.isEnabled = true
                if (file == null || uri == null) {
                    Toast.makeText(this, "Gagal mengekspor. Coba lagi.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Tersimpan di Download/TangkapTeks", Toast.LENGTH_LONG).show()
                    if (share) {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = file.mime
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(send, getString(R.string.share)))
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        recognizer.close()
        io.shutdown()
    }
}
