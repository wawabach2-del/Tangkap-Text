package id.tangkapteks

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val io = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private var bitmap: Bitmap? = null
    private var lines: List<TextLine> = emptyList()
    private var result: Bitmap? = null
    private var cameraUri: Uri? = null

    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var toggle: MaterialButtonToggleGroup
    private lateinit var preview: ImageView
    private lateinit var panelLayout: View
    private lateinit var panelText: View
    private lateinit var panelPhoto: View
    private lateinit var layoutView: LayoutView
    private lateinit var plainText: TextView
    private lateinit var resultImage: ImageView
    private lateinit var btnScan: Button
    private lateinit var vScroll: ScrollView

    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadUri(uri)
    }
    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) cameraUri?.let { loadUri(it) }
    }

    private var keepSplash = true

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        // Layar pembuka (logo QiAKU) tampil sebentar, sekitar 1 detik
        splash.setKeepOnScreenCondition { keepSplash }
        Handler(Looper.getMainLooper()).postDelayed({ keepSplash = false }, 1000)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        toggle = findViewById(R.id.toggle)
        preview = findViewById(R.id.preview)
        panelLayout = findViewById(R.id.panelLayout)
        panelText = findViewById(R.id.panelText)
        panelPhoto = findViewById(R.id.panelPhoto)
        layoutView = findViewById(R.id.layoutView)
        plainText = findViewById(R.id.plainText)
        resultImage = findViewById(R.id.resultImage)
        btnScan = findViewById(R.id.btnScan)
        vScroll = findViewById(R.id.vScroll)

        findViewById<Button>(R.id.btnGallery).setOnClickListener {
            pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<Button>(R.id.btnCamera).setOnClickListener { openCamera() }
        findViewById<Button>(R.id.btnRotate).setOnClickListener {
            val b = bitmap ?: return@setOnClickListener
            io.execute {
                val r = ImageUtils.rotate90(b)
                runOnUiThread { setBitmap(r) }
            }
        }
        btnScan.setOnClickListener { scan() }

        toggle.addOnButtonCheckedListener { _, id, checked -> if (checked) showTab(id) }

        layoutView.onLineTap = { editLine(it) }
        findViewById<CheckBox>(R.id.chkOriginal).setOnCheckedChangeListener { _, on -> layoutView.showOriginal = on }
        findViewById<SeekBar>(R.id.zoom).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val base = vScroll.width
                if (base > 0) layoutView.targetWidth = base * (100 + p) / 100
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnCopy).setOnClickListener { copy(false) }
        findViewById<Button>(R.id.btnCopyRich).setOnClickListener { copy(true) }
        findViewById<Button>(R.id.btnShare).setOnClickListener {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, TextBuilder.plain(lines))
            }
            startActivity(Intent.createChooser(send, getString(R.string.share)))
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveResult() }
    }

    // ---------- foto ----------

    private fun openCamera() {
        val dir = File(cacheDir, "images").apply { mkdirs() }
        val file = File(dir, "capture.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        cameraUri = uri
        takePicture.launch(uri)
    }

    private fun loadUri(uri: Uri) {
        setStatus("Membuka foto...")
        io.execute {
            val bm = try { ImageUtils.load(this, uri) } catch (e: Exception) { null }
            runOnUiThread {
                if (bm == null) setStatus("Foto tidak bisa dibuka.") else setBitmap(bm)
            }
        }
    }

    private fun setBitmap(bm: Bitmap) {
        bitmap = bm
        lines = emptyList()
        result = null
        toggle.visibility = View.GONE
        panelLayout.visibility = View.GONE
        panelText.visibility = View.GONE
        panelPhoto.visibility = View.GONE
        preview.visibility = View.VISIBLE
        preview.setImageBitmap(bm)
        btnScan.isEnabled = true
        setStatus("Foto siap. Tekan Tangkap teks.")
    }

    private fun setStatus(t: String) { status.text = t }

    // ---------- OCR ----------

    private fun scan() {
        val bm = bitmap ?: return
        btnScan.isEnabled = false
        progress.visibility = View.VISIBLE
        setStatus("Membaca teks...")
        recognizer.process(InputImage.fromBitmap(bm, 0))
            .addOnSuccessListener { text ->
                io.execute {
                    val out = mutableListOf<TextLine>()
                    for (block in text.textBlocks) for (ln in block.lines) {
                        val r = ln.boundingBox ?: continue
                        if (ln.text.isBlank()) continue
                        val box = Rect(r)
                        val bg = ImageUtils.sampleBackground(bm, box)
                        val fg = ImageUtils.sampleTextColor(bm, box, bg)
                        out.add(TextLine(ln.text, ln.text, box, color = fg, bg = bg))
                    }
                    val page = ImageUtils.sampleBackground(bm, Rect(0, 0, bm.width - 1, bm.height - 1))
                    runOnUiThread { showResults(out, page) }
                }
            }
            .addOnFailureListener {
                progress.visibility = View.GONE
                btnScan.isEnabled = true
                setStatus("Gagal membaca teks. Coba foto lain.")
            }
    }

    private fun showResults(found: List<TextLine>, pageBg: Int) {
        progress.visibility = View.GONE
        btnScan.isEnabled = true
        if (found.isEmpty()) {
            setStatus("Tidak ada teks yang terbaca di foto ini.")
            return
        }
        lines = found
        setStatus("Selesai: ${found.size} baris teks.")
        layoutView.pageBg = pageBg
        layoutView.bitmap = bitmap
        layoutView.lines = lines
        vScroll.post { layoutView.targetWidth = vScroll.width }
        toggle.visibility = View.VISIBLE
        if (toggle.checkedButtonId == R.id.tabLayout) showTab(R.id.tabLayout) else toggle.check(R.id.tabLayout)
    }

    private fun showTab(id: Int) {
        preview.visibility = View.GONE
        panelLayout.visibility = if (id == R.id.tabLayout) View.VISIBLE else View.GONE
        panelText.visibility = if (id == R.id.tabText) View.VISIBLE else View.GONE
        panelPhoto.visibility = if (id == R.id.tabPhoto) View.VISIBLE else View.GONE
        when (id) {
            R.id.tabLayout -> layoutView.invalidate()
            R.id.tabText -> plainText.text = TextBuilder.plain(lines)
            R.id.tabPhoto -> buildPhoto()
        }
    }

    // ---------- edit ----------

    private fun editLine(l: TextLine) {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
        }
        val et = EditText(this).apply {
            setText(l.text)
            setSelection(text.length)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val cbBold = CheckBox(this).apply { text = getString(R.string.bold); isChecked = l.bold }
        val cbItalic = CheckBox(this).apply { text = getString(R.string.italic); isChecked = l.italic }
        col.addView(et)
        col.addView(cbBold)
        col.addView(cbItalic)
        AlertDialog.Builder(this)
            .setTitle(R.string.edit_line)
            .setView(col)
            .setPositiveButton(R.string.ok) { _, _ ->
                l.text = et.text.toString()
                l.bold = cbBold.isChecked
                l.italic = cbItalic.isChecked
                layoutView.invalidate()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------- salin ----------

    private fun copy(rich: Boolean) {
        val plain = TextBuilder.plain(lines)
        val clip = if (rich) ClipData.newHtmlText("Tangkap Teks", plain, TextBuilder.html(lines))
        else ClipData.newPlainText("Tangkap Teks", plain)
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
        Toast.makeText(this, if (rich) "Tersalin dengan format" else "Tersalin", Toast.LENGTH_SHORT).show()
    }

    // ---------- ganti teks di foto ----------

    private fun buildPhoto() {
        val bm = bitmap ?: return
        val snapshot = lines.map { it.copy(box = Rect(it.box)) }
        io.execute {
            val out = Compositor.compose(bm, snapshot)
            runOnUiThread {
                result = out
                resultImage.setImageBitmap(out)
                val n = snapshot.count { it.changed }
                if (n == 0) Toast.makeText(this, "Belum ada baris yang diubah. Edit dulu di tab Tata letak.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun saveResult() {
        val out = result ?: bitmap ?: return
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "TangkapTeks_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/TangkapTeks")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(this, "Gagal menyimpan gambar", Toast.LENGTH_SHORT).show()
            return
        }
        contentResolver.openOutputStream(uri)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        Toast.makeText(this, "Tersimpan di Galeri (Pictures/TangkapTeks)", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        recognizer.close()
        io.shutdown()
    }
}
